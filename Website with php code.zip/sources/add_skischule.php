<?php
  $config = parse_ini_file('config.ini');

  // establish database connection
  $conn = oci_connect($config['user'], $config['pass'], $config['database']);
  if (!$conn) exit;
?>

<?php
    $gebiet_id = $_GET['gebiet_id'];
    $name = $_GET['name'];
    $strasse = $_GET['strasse'];
    $plz = $_GET['plz'];
    $ort = $_GET['ort'];  

    //Prepare insert statement
    $sql = "INSERT INTO Skischule (Gebiet_ID, Name, Strasse, PLZ, Ort)
            VALUES ($gebiet_id, 
                    '$name',
                    '$strasse',
                    $plz,
                    '$ort')";

//Parse and execute statement
    $insert = oci_parse($conn, $sql);
    oci_execute($insert);
    $conn_err=oci_error($conn);
    $insert_err=oci_error($insert);
    if(!$conn_err & !$insert_err){
        print("Successfully inserted");
        print("<br>");
    }
    //Print potential errors and warnings
    else {
        print($conn_err);
        print_r($insert_err);
    }

    oci_free_statement($insert);
    header("Location: http://wwwlab.cs.univie.ac.at/~a1247560/dbs/skigebiet_info.php?id=$gebiet_id");
?>