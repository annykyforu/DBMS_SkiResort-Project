<?php
  $config = parse_ini_file('config.ini');

  // establish database connection
  $conn = oci_connect($config['user'], $config['pass'], $config['database']);
  if (!$conn) exit;
?>

<?php
    $gebiet_id = $_GET['id'];
    $name = $_GET['name'];

//echo $gebiet_id;
//echo $name;


    //Prepare delete statement
    $sql = "DELETE FROM Skischule
            WHERE name = '$name'";

//Parse and execute statement
    $delete = oci_parse($conn, $sql);
    oci_execute($delete);
    $conn_err=oci_error($conn);
    $delete_err=oci_error($delete);
    if(!$conn_err & !$delete_err){
        print("Successfully deleted");
        print("<br>");
    }
    //Print potential errors and warnings
    else {
        print($conn_err);
        print_r($insert_err);
    }

    oci_free_statement($delete);
    header("Location: http://wwwlab.cs.univie.ac.at/~a1247560/dbs/skigebiet_info.php?id=$gebiet_id");
?>