<?php
  $config = parse_ini_file('config.ini');

  // establish database connection
  $conn = oci_connect($config['user'], $config['pass'], $config['database']);
  if (!$conn) exit;
?>

<html lang="en">
  <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
      <title>Meilenstein 5</title>

      <!-- Bootstrap core CSS -->
      <link href="css/bootstrap.css" rel="stylesheet">
      <link href="css/starter-template.css" rel="stylesheet">
  </head>
    
  <body>
      <nav class="navbar navbar-inverse navbar-fixed-top">
          <div class="container">
              <div class="navbar-header">
                  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                      <span class="sr-only">Toggle navigation</span>
                      <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                  </button>
                  <a class="navbar-brand" href="skigebiet.php">Zurück</a>
              </div>
          </div>
      </nav>
      
      <div class="container">
        <div class="bootstrap">
            <center>
                <h1>
                    <?php
                        $id=$_GET['id'];        // Collecting data from query string
                        if(!is_numeric($id)){   // Checking data it is a number or not
                            echo "Data Error";
                            exit;
                        }
                        $stid = oci_parse($conn, "SELECT sg.bezeichnung
                                                  FROM skigebiet sg
                                                  WHERE sg.gebiet_id = '$id'");    
                        oci_execute($stid);
                        while (($row = oci_fetch_object($stid)) != false) {
                            // Use upper case attribute names for each standard Oracle column
                            echo $row->BEZEICHNUNG;
                        }
                        oci_free_statement($stid);
                    ?>
                </h1>
                <h3>
                    <?php
                        $stnames = oci_parse($conn, "SELECT o.land, o.staat
                                                     FROM skigebiet sg JOIN ort o ON sg.ort_id = o.ort_id
                                                     WHERE sg.gebiet_id = '$id'");    
                        oci_execute($stnames);
                        while (($row = oci_fetch_object($stnames)) != false) {
                            // Use upper case attribute names for each standard Oracle column
                            echo $row->LAND;
                            echo ", ";
                            echo $row->STAAT;
                        }
                        oci_free_statement($stnames);
                    ?>
                </h3>
            </center>
        </div>
      </div>
      
      <?php
        $sql = "SELECT l.typ,
                       l.anzahl
                FROM lift l,
                     skigebiet sg
                WHERE sg.gebiet_id = '$id' AND
                      sg.gebiet_id = l.gebiet_id";
            // execute sql statement
            $stmt = oci_parse($conn, $sql);
            oci_execute($stmt);
      ?>
      <div class="container">
            <div class="bootstrap">
              <table class="table table-condensed table-hover table-responsive w-auto">
                  <caption>Lifte</caption>
                  <thead>
                    <tr>
                      <th scope="col">Typ</th>
                      <th scope="col">Anzahl</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                      // fetch rows of the executed sql query
                      while ($row = oci_fetch_assoc($stmt)) {
                        echo "<tr>";
                        echo "<td>" . $row['TYP'] . "</td>";
                        echo "<td>" . $row['ANZAHL'] . "</td>";
                        echo "</tr>";
                      }
                    oci_free_statement($stmt);
                    ?>
                  </tbody>
                </table>
            </div>
        </div> 
      
      <?php
        $sql = "SELECT p.typ,
                       p.strecke
                FROM piste p,
                     skigebiet sg
                WHERE sg.gebiet_id = '$id' AND
                      sg.gebiet_id = p.gebiet_id";
            // execute sql statement
            $stmt = oci_parse($conn, $sql);
            oci_execute($stmt);
      ?>
      <div class="container">
            <div class="bootstrap">
              <table class="table table-condensed table-hover table-responsive w-auto">
                  <caption>Piste</caption>
                  <thead>
                    <tr>
                      <th scope="col">Typ</th>
                      <th scope="col">Strecke, km</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                      // fetch rows of the executed sql query
                      while ($row = oci_fetch_assoc($stmt)) {
                        echo "<tr>";
                        echo "<td>" . $row['TYP'] . "</td>";
                        echo "<td>" . $row['STRECKE'] . "</td>";
                        echo "</tr>";
                      }
                      oci_free_statement($stmt);
                    ?>
                  </tbody>
                </table>
            </div>
        </div>      
      
      <?php
        $sql = "SELECT sch.name,
                       sch.strasse,
                       sch.plz,
                       sch.ort
                FROM skigebiet sg,
                     skischule sch
                WHERE sg.gebiet_id = '$id' AND
                      sg.gebiet_id = sch.gebiet_id";
            // execute sql statement
            $stmt = oci_parse($conn, $sql);
            oci_execute($stmt);
      ?>  
      <div class="container">
        <div class="bootstrap">
          <table class="table table-condensed table-hover table-responsive w-auto">
              <caption>Skischule</caption>
              <thead>
                <tr>
                  <th scope="col">Name</th>
                  <th scope="col">Adresse</th>
                  <th scope="col"></th>
                </tr>
              </thead>
              <tbody>
                <?php
                  // fetch rows of the executed sql query
                  while ($row = oci_fetch_assoc($stmt)) {
                    echo "<tr>";
                    echo "<td>" . $row['NAME'] . "</td>";
                    echo "<td>" . $row['STRASSE'] . ", " . $row['PLZ'] . " " . $row['ORT'] . "</td>";
                    echo "<td><center>
                            <a href='delete_skischule.php?id=".$id."&name=".$row['NAME']."'>
                                <button class='btn btn-danger btn-sm'>
                                    <span class='glyphicon glyphicon-trash'></span>
                                </button>
                            </a>
                          </center></td>";
                    echo "</tr>";
                  }
                  oci_free_statement($stmt);
                ?>
              </tbody>
            </table>
        </div>
      </div>         

      <form class="form-inline" align="center" action="add_skischule.php">
          <div class="invisible">
              <div class="form-group"> 
                  <div class="col-sm-10"> <!-- This is a new div -->
                      <input type="int" class="form-control" id="gebiet_id" name="gebiet_id" value= <?php echo $id; ?>>
                  </div>
              </div>
          </div>
          <b>Eine neue Skischule hinzufügen:</b> <br>
          <div class="form-group"> 
              <div class="col-sm-10"> <!-- This is a new div -->
                  <input type="varchar" class="form-control" id="name" name="name" required placeholder="Skischule name">
              </div>
          </div>
          
          <div class="form-group"> 
              <div class="col-sm-10"> <!-- This is a new div -->
                  <input type="varchar" class="form-control" id="strasse" name="strasse" required placeholder="Strasse">
              </div>
          </div>
            
          <div class="form-group"> 
              <div class="col-sm-10"> <!-- This is a new div -->
                  <input type="int" class="form-control" id="plz" name="plz" required placeholder="PLZ">
              </div>
          </div>
            
          <div class="form-group"> 
              <div class="col-sm-10"> <!-- This is a new div -->
                 <input type="varchar" class="form-control" id="ort" name="ort" required placeholder="Ort">
              </div>
          </div>
            
          <div class="form-group"> 
              <div class="col-sm-10 col-sm-offset-1"> <!--New div, offset because there is no label -->
                  <button type="submit" class="btn btn-primary">Add</button>
              </div>
          </div>		
      </form>
    
      <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.js"></script>
      <!-- Include all compiled plugins (below), or include individual files as needed -->
      <script src="js/bootstrap.js"></script>
  </body>
</html>