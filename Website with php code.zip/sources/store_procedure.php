<?php
  $config = parse_ini_file('config.ini');

  // establish database connection
  $conn = oci_connect($config['user'], $config['pass'], $config['database']);
  if (!$conn) exit;
?>

<html lang="en">
  <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
      <title>Meilenstein 5</title>

      <!-- Bootstrap core CSS -->
      <link href="css/bootstrap.css" rel="stylesheet">
      <link href="css/starter-template.css" rel="stylesheet">
  </head>
    
  <body>
      <nav class="navbar navbar-inverse navbar-fixed-top">
          <div class="container">
              <div class="navbar-header">
                  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                      <span class="sr-only">Toggle navigation</span>
                      <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                  </button>
                  <a class="navbar-brand" href="index.html">Home</a>
              </div>
              <div id="navbar" class="collapse navbar-collapse">
                  <ul class="nav navbar-nav navbar-right">
                      <li><a href="skigebiet.php">Skigebiet</a></li>
                      <li><a href="berg.php">Berg</a></li>
                      <li><a href="hotel.php">Hotel</a></li>
                      <li><a href="skischule.php">Skischule</a></li>
                      <li class="active"><a href="store_procedure.php">Test Procedure</a></li>
                  </ul>
              </div><!--/.nav-collapse -->
          </div>
      </nav>   
              
      <div align="center">
          <p class="lead">
            This is a page to run a PHP Store Procedure.
          </p>
          <form id='searchabt' action='store_procedure.php' method='get'>
              Suche wieviele Skiegebiete gibt es in einem Staat:
              <input id='p_staat' name='p_staat' type='varchar' size='25' value='<?php if (isset($_GET['p_staat'])) echo $_GET['p_staat']; ?>' />
              <input id='submit' type='submit' value='Aufruf Stored Procedure!' />
          </form>
        
          <?php
            //Handle Stored Procedure
            if (isset($_GET['p_staat']))
            {
                //Call Stored Procedure  
                $p_staat = $_GET['p_staat'];
                $p_geb='';
                $sproc = oci_parse($conn, 'begin qty_geb(:p1, :p2); end;');
                //Bind variables, p1=input (p_staat), p2=output (p_geb)
                oci_bind_by_name($sproc, ':p1', $p_staat);
                oci_bind_by_name($sproc, ':p2', $p_geb, 20);
                oci_execute($sproc);
                $conn_err=oci_error($conn);
                $proc_err=oci_error($sproc);
                //If there have been no Connection or Database errors, print department
                if(!$conn_err && !$proc_err){
                   echo("<b>" . $p_staat . " hat " . $p_geb . " " . " Skigebiete.</b>");  // prints OUT parameter of stored procedure
                }
                else{
                  //Print potential errors and warnings
                  print($conn_err);
                  print_r($proc_err);
                } 
            oci_free_statement($sproc);
            }
             // clean up connections
             oci_close($conn);
          ?>
      </div>

      <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.js"></script>
      <!-- Include all compiled plugins (below), or include individual files as needed -->
      <script src="js/bootstrap.js"></script>
  </body>
</html>