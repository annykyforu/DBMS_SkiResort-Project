import java.sql.*;
import oracle.jdbc.driver.*;

public class TestDataGenerator {

  public static void main(String args[])
  {
    try {
      Class.forName("oracle.jdbc.driver.OracleDriver");
      String database = "jdbc:oracle:thin:@oracle-lab.cs.univie.ac.at:1521:lab";
      String user = "";
      String pass = "";

      // establish connection to database
      Connection con = DriverManager.getConnection(database, user, pass);
      Statement stmt = con.createStatement();


      // insert a single test datasets into table Ort
      try {
         String insertSql = "INSERT INTO Ort VALUES (112233, 'Staat_ok','Land_ok')";
         stmt.executeUpdate(insertSql);
      } catch (Exception e) {
         System.err.println("Fehler beim Einfuegen des Datensatzes: " + e.getMessage());
      }
      // check number of datasets in Ort table
      ResultSet rs0 = stmt.executeQuery("SELECT COUNT(*) FROM Ort");
      if (rs0.next()) {
        int count0 = rs0.getInt(1);
        System.out.println("Number of test datasets in Ort: " + count0);
      }


      // insert multiple dataset into Ort
      int co = 1;
      for (int s = 1; s <= 30; s++){
         for (int l = 1; l <= 15; l++){
            try {
               String insertSql = "INSERT INTO Ort VALUES ('"+co+"', 'Staat_"+s+"', '"+s+"_Land_"+l+"')";
               stmt.executeUpdate(insertSql);
            } catch (Exception e) {
               System.err.println("Fehler beim Einfuegen des Datensatzes: " + e.getMessage());
            }
            co++;
         }
      }
      // check number of datasets in Ort table
       ResultSet rs1 = stmt.executeQuery("SELECT COUNT(*) FROM Ort");
       if (rs1.next()) {
         int count1 = rs1.getInt(1);
         System.out.println("Number of datasets in Ort: " + count1);
      }


      // insert dataset into Berg
      for (int cb = 1; cb <= 450; cb++){
         try {
            String insertSql = "INSERT INTO Berg (Ort_ID, Name, Hoehe) VALUES ('"+cb+"', 'Name_"+cb+"', '"+cb+"')";
            stmt.executeUpdate(insertSql);
         } catch (Exception e) {
            System.err.println("Fehler beim Einfuegen des Datensatzes: " + e.getMessage());
         }
      }
      // check number of datasets in Berg table
      ResultSet rs2 = stmt.executeQuery("SELECT COUNT(*) FROM Berg");
      if (rs2.next()) {
         int count2 = rs2.getInt(1);
         System.out.println("Number of datasets in Berg: " + count2);
      }


      // insert dataset into Hotel
      for (int ch = 1; ch <= 450; ch++){
         try {
            String insertSql = "INSERT INTO Hotel VALUES ('"+ch+"', '"+ch+"', 'Name_"+ch+"', 'Strasse_"+ch+"', '"+ch+"', 'Ort_"+ch+"')";
            stmt.executeUpdate(insertSql);
         } catch (Exception e) {
            System.err.println("Fehler beim Einfuegen des Datensatzes: " + e.getMessage());
         }
      }
      // check number of datasets in Hotel table
      ResultSet rs3 = stmt.executeQuery("SELECT COUNT(*) FROM Hotel");
      if (rs3.next()) {
         int count3 = rs3.getInt(1);
         System.out.println("Number of datasets in Hotel: " + count3);
      }


      // insert dataset into Skigebiet
      for (int cs = 1; cs <= 450; cs++){
         try {
             String insertSql = "INSERT INTO Skigebiet VALUES ('"+cs+"', '"+cs+"', 'Bezeichnung_"+cs+"')";
             stmt.executeUpdate(insertSql);
         } catch (Exception e) {
             System.err.println("Fehler beim Einfuegen des Datensatzes: " + e.getMessage());
         }
      }
      // check number of datasets in Skigebiet table
      ResultSet rs4 = stmt.executeQuery("SELECT COUNT(*) FROM Skigebiet");
      if (rs4.next()) {
         int count4 = rs4.getInt(1);
         System.out.println("Number of datasets in Skigebiet: " + count4);
      }


      // insert dataset into Lift
      int clid = 1;
      for (int cl = 1; cl <= 450; cl++){
         try {
            String insertSql = "INSERT INTO Lift VALUES ('"+cl+"', '"+clid+"', 'Schlepplifte', 10)";
            stmt.executeUpdate(insertSql);
            clid++;
            insertSql = "INSERT INTO Lift VALUES ('"+cl+"', '"+clid+"', 'Sessellifte', 15)";
            stmt.executeUpdate(insertSql);
            clid++;
            insertSql = "INSERT INTO Lift VALUES ('"+cl+"', '"+clid+"', 'Kabinenbahn', 5)";
            stmt.executeUpdate(insertSql);
            clid++;
            insertSql = "INSERT INTO Lift VALUES ('"+cl+"', '"+clid+"', 'Standseilbahn', 2)";
            stmt.executeUpdate(insertSql);
            clid++;
         } catch (Exception e) {
            System.err.println("Fehler beim Einfuegen des Datensatzes: " + e.getMessage());
         }
      }
      // check number of datasets in Lift table
      ResultSet rs5 = stmt.executeQuery("SELECT COUNT(*) FROM Lift");
      if (rs5.next()) {
          int count5 = rs5.getInt(1);
          System.out.println("Number of datasets in Lift: " + count5);
      }


      // insert dataset into Piste
      int cpid = 1;
      for (int cp = 1; cp <= 450; cp++) {
         try {
            String insertSql = "INSERT INTO Piste VALUES ('"+cp+"', '"+cpid+"', 'Leicht', 20)";
            stmt.executeUpdate(insertSql);
            cpid++;
            insertSql = "INSERT INTO Piste VALUES ('"+cp+"', '"+cpid+"', 'Mittel', 30)";
            stmt.executeUpdate(insertSql);
            cpid++;
            insertSql = "INSERT INTO Piste VALUES ('"+cp+"', '"+cpid+"', 'Schwer', 15)";
            stmt.executeUpdate(insertSql);
            cpid++;
            insertSql = "INSERT INTO Piste VALUES ('"+cp+"', '"+cpid+"', 'Freeride', 7)";
            stmt.executeUpdate(insertSql);
            cpid++;
         } catch (Exception e) {
            System.err.println("Fehler beim Einfuegen des Datensatzes: " + e.getMessage());
         }
      }
      // check number of datasets in Piste table
      ResultSet rs6 = stmt.executeQuery("SELECT COUNT(*) FROM Piste");
      if (rs6.next()) {
          int count6 = rs6.getInt(1);
          System.out.println("Number of datasets in Piste: " + count6);
      }


      // insert dataset into Rettung
      try {
         String insertSql = "INSERT INTO Rettung VALUES ('"+1+"', 'Bergrettung Zentrale', '"+140+"', NULL)";
         stmt.executeUpdate(insertSql);
      } catch (Exception e) {
         System.err.println("Fehler beim Einfuegen des Datensatzes: " + e.getMessage());
      }
      for (int cr = 2; cr <= 451; cr++){
         try {
            String insertSql = "INSERT INTO Rettung VALUES ('"+cr+"', 'Bergrettung_"+cr+"', '123-345-567', '"+1+"')";
            stmt.executeUpdate(insertSql);
         } catch (Exception e) {
            System.err.println("Fehler beim Einfuegen des Datensatzes: " + e.getMessage());
         }
      }
      // check number of datasets in Rettung table
      ResultSet rs7 = stmt.executeQuery("SELECT COUNT(*) FROM Rettung");
      if (rs7.next()) {
         int count7 = rs7.getInt(1);
         System.out.println("Number of datasets in Rettung: " + count7);
      }


      // insert dataset into Einsatz
      for (int cgid = 1; cgid <=450; cgid++){
         int crid = cgid+1;
         try {
            String insertSql = "INSERT INTO Einsatz VALUES ('"+cgid+"', '"+crid+"')";
            stmt.executeUpdate(insertSql);
         } catch (Exception e) {
            System.err.println("Fehler beim Einfuegen des Datensatzes: " + e.getMessage());
         }
      }
      // check number of datasets in Einsatz table
      ResultSet rs8 = stmt.executeQuery("SELECT COUNT(*) FROM Einsatz");
      if (rs8.next()) {
         int count8 = rs8.getInt(1);
         System.out.println("Number of datasets in Einsatz: " + count8);
      }


      // insert dataset into Skischule
      for (int cgid = 1; cgid <= 450; cgid++){
//         int csid = cgid;
         try {
            String insertSql = "INSERT INTO Skischule (Gebiet_ID, Name, Strasse, PLZ, Ort) VALUES ('"+cgid+"', 'Name_"+cgid+"', 'Strasse "+cgid+"', '"+cgid+""+cgid+"', 'Ort_"+cgid+"')";
            stmt.executeUpdate(insertSql);
         } catch (Exception e) {
            System.err.println("Fehler beim Einfuegen des Datensatzes: " + e.getMessage());
         }
      }
      // check number of datasets in Skischule table
      ResultSet rs9 = stmt.executeQuery("SELECT COUNT(*) FROM Skischule");
      if (rs9.next()) {
         int count9 = rs9.getInt(1);
         System.out.println("Number of datasets in Skischule: " + count9);
      }


      // insert dataset into MitarbeiterIn
      int svnr = 1111223344;
      int skisch = 1;
      for(int i=1; i<=4500; i++){
         try {
            String insertSql = "INSERT INTO MitarbeiterIn VALUES ('"+skisch+"', '"+svnr+"', 'Vorname_"+i+"', 'Nachname_"+i+"', 'Vollzeit')";
            stmt.executeUpdate(insertSql);
         } catch (Exception e) {
            System.err.println("Fehler beim Einfuegen des Datensatzes: " + e.getMessage());
         }
         svnr = svnr + 1010101;
         if ((i % 10) == 0) {
            skisch++;
         }
      }
      // check number of datasets in MitarbeiterIn table
      ResultSet rs10 = stmt.executeQuery("SELECT COUNT(*) FROM MitarbeiterIn");
      if (rs10.next()) {
         int count10 = rs10.getInt(1);
         System.out.println("Number of datasets in MitarbeiterIn: " + count10);
      }


      // insert dataset into Lehrer
      svnr = 1111223344;
      for (int countl = 1; countl <= 3600; countl++){
         try {
            String insertSql = "INSERT INTO Lehrer VALUES ('"+svnr+"', '"+countl+"', 'Ausbildung_"+countl+"')";
            stmt.executeUpdate(insertSql);
         } catch (Exception e) {
            System.err.println("Fehler beim Einfuegen des Datensatzes: " + e.getMessage());
         }
         svnr = svnr + 1010101;
      }
      // check number of datasets in Lehrer table
      ResultSet rs11 = stmt.executeQuery("SELECT COUNT(*) FROM Lehrer");
      if (rs11.next()) {
          int count11 = rs11.getInt(1);
          System.out.println("Number of datasets in Lehrer: " + count11);
      }


      // insert dataset into Buerokraft
      for (int countb = 1; countb <= 900; countb++){
         try {
            String insertSql = "INSERT INTO Buerokraft VALUES ('"+svnr+"', '"+countb+"')";
            stmt.executeUpdate(insertSql);
         } catch (Exception e) {
            System.err.println("Fehler beim Einfuegen des Datensatzes: " + e.getMessage());
         }
         svnr = svnr + 1010101;
      }
      // check number of datasets in Buerokraft table
      ResultSet rs12 = stmt.executeQuery("SELECT COUNT(*) FROM Buerokraft");
      if (rs12.next()) {
         int count12 = rs12.getInt(1);
         System.out.println("Number of datasets in Buerokraft: " + count12);
      }


      // clean up connections
      rs0.close();
      rs1.close();
      rs2.close();
      rs3.close();
      rs4.close();
      rs5.close();
      rs6.close();
      rs7.close();
      rs8.close();
      rs9.close();
      rs10.close();
      rs11.close();
      rs12.close();
      stmt.close();
      con.close();
    } catch (Exception e) {
      System.err.println(e.getMessage());
    }
  }
}
