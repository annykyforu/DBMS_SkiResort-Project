<?php
  $config = parse_ini_file('config.ini');

  // establish database connection
  $conn = oci_connect($config['user'], $config['pass'], $config['database']);
  if (!$conn) exit;
?>

<html lang="en">
  <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
      <title>Meilenstein 5</title>

      <!-- Bootstrap core CSS -->
      <link href="css/bootstrap.css" rel="stylesheet">
      <link href="css/starter-template.css" rel="stylesheet">
  </head>
    
  <body>
      <nav class="navbar navbar-inverse navbar-fixed-top">
          <div class="container">
              <div class="navbar-header">
                  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                      <span class="sr-only">Toggle navigation</span>
                      <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                  </button>
                  <a class="navbar-brand" href="index.html">Home</a>
              </div>
              <div id="navbar" class="collapse navbar-collapse">
                  <ul class="nav navbar-nav navbar-right">
                      <li><a href="skigebiet.php">Skigebiet</a></li>
                      <li><a href="berg.php">Berg</a></li>
                      <li class="active"><a href="hotel.php">Hotel</a></li>
                      <li><a href="skischule.php">Skischule</a></li>
                      <li><a href="store_procedure.php">Store Procedure</a></li>
                  </ul>
              </div><!--/.nav-collapse -->
          </div>
      </nav>
      
      
      <div align="center">
          <br>
          <form id='searchform' action='hotel.php' method='get'>
          <a href='hotel.php'>Alle Hotels</a> oder
          <input id='search' name='search' type='varchar' size='35' value='<?php  if (isset($_GET['search'])) echo $_GET['search']; ?>' placeholder="Suche nach Hotel im Ort...">
          <input id='submit' type='submit' value='Los!'>
          </form>
      </div>
      
      <?php
          // check if search view of list view
          if (isset($_GET['search'])) {
            $sql = "SELECT
                        hotel_id, name, strasse, plz, hotel.ort, ort.staat
                    FROM
                        hotel LEFT JOIN ort
                    ON
                        hotel.ort_id = ort.ort_id
                    WHERE
                        ort LIKE '" . $_GET['search'] . "'
                    ORDER by ort.staat asc";
          } else {
            $sql = "SELECT
                        hotel_id, name, strasse, plz, hotel.ort, ort.staat
                    FROM
                        hotel LEFT JOIN ort
                    ON
                        hotel.ort_id = ort.ort_id
                    ORDER by ort.staat asc";
          }

          // execute sql statement
          $stmt = oci_parse($conn, $sql);
          oci_execute($stmt);
        ?>

        <div class="container">
            <div class="bootstrap">
              <table class="table table-condensed table-hover table-responsive w-auto">
                  <thead>
                    <tr>
                      <th scope="col">Hotel #</th>
                      <th scope="col">Name</th>
                      <th scope="col">Adresse</th>
                      <th scope="col">Staat</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                        // fetch rows of the executed sql query
                          while ($row = oci_fetch_assoc($stmt)) {
                              echo "<tr>";
                              echo "<td>" . $row['HOTEL_ID'] . "</td>";
                              echo "<td>" . $row['NAME'] . "</td>";
                              echo "<td>" . $row['STRASSE'] . ", " . $row['PLZ'] . " " . $row['ORT'] . "</td>";
                              echo "<td>" . $row['STAAT'] . "</td>";
                              echo "</tr>";
                          }
                    ?>
                  </tbody>
                </table>
            </div>
        </div>
        <div>Insgesamt <?php echo oci_num_rows($stmt); ?> Hotel(s) gefunden!</div>
        <?php  oci_free_statement($stmt); ?>
      
      <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.js"></script>
      <!-- Include all compiled plugins (below), or include individual files as needed -->
      <script src="js/bootstrap.js"></script>
  </body>
</html>