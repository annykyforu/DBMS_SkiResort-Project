<?php
  $config = parse_ini_file('config.ini');

  // establish database connection
  $conn = oci_connect($config['user'], $config['pass'], $config['database']);
  if (!$conn) exit;
?>

<html lang="en">
  <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
      <title>Meilenstein 5</title>

      <!-- Bootstrap core CSS -->
      <link href="css/bootstrap.css" rel="stylesheet">
      <link href="css/starter-template.css" rel="stylesheet">
  </head>
    
  <body>
      <nav class="navbar navbar-inverse navbar-fixed-top">
          <div class="container">
              <div class="navbar-header">
                  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                      <span class="sr-only">Toggle navigation</span>
                      <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                      <span class="icon-bar"></span>
                  </button>
                  <a class="navbar-brand" href="index.html">Home</a>
              </div>
              <div id="navbar" class="collapse navbar-collapse">
                  <ul class="nav navbar-nav navbar-right">
                      <li class="active"><a href="skigebiet.php">Skigebiet</a></li>
                      <li><a href="berg.php">Berg</a></li>
                      <li><a href="hotel.php">Hotel</a></li>
                      <li><a href="skischule.php">Skischule</a></li>
                      <li><a href="store_procedure.php">Store Procedure</a></li>
                  </ul>
              </div><!--/.nav-collapse -->
          </div>
      </nav>
      
      
      <div>
          <center>
          <br>
          <form id='searchform' action='skigebiet.php' method='get'>
          <a href='skigebiet.php'>Alle Skigebiet</a> oder
          <input id='search' name='search' type='varchar' size='35' value='<?php  if (isset($_GET['search'])) echo $_GET['search']; ?>' placeholder="Suche nach Skigebiet...">
          <input id='submit' type='submit' value='Los!'>
          </form>
          </center>
      </div>
      
      <?php
        // check if search view of list view
        if (isset($_GET['search'])) {
            $sql = "SELECT   sg.gebiet_id,
                             o.staat,
                             sg.bezeichnung,
                             l.lifteanzahl,
                             p.pistestrecke
                    FROM skigebiet sg  JOIN ort o ON sg.ort_id = o.ort_id
                                       JOIN (SELECT Gebiet_ID, Sum(Anzahl) AS lifteanzahl
                                            FROM Lift
                                            GROUP BY Gebiet_ID) l ON sg.gebiet_id = l.gebiet_id
                                       JOIN (SELECT Gebiet_ID, Sum(Strecke) as pistestrecke
                                            FROM Piste
                                            GROUP BY Gebiet_ID) p ON sg.gebiet_id = p.gebiet_id
                    WHERE
                        sg.bezeichnung like '%" . $_GET['search'] . "%'
                    ORDER BY o.staat asc";
        } else {
            $sql = "SELECT   sg.gebiet_id,
                             o.staat,
                             sg.bezeichnung,
                             l.lifteanzahl,
                             p.pistestrecke
                    FROM skigebiet sg  JOIN ort o ON sg.ort_id = o.ort_id
                                       JOIN (SELECT Gebiet_ID, Sum(Anzahl) AS lifteanzahl
                                            FROM Lift
                                            GROUP BY Gebiet_ID) l ON sg.gebiet_id = l.gebiet_id
                                       JOIN (SELECT Gebiet_ID, Sum(Strecke) as pistestrecke
                                            FROM Piste
                                            GROUP BY Gebiet_ID) p ON sg.gebiet_id = p.gebiet_id
                    ORDER BY o.staat asc";
        }

          // execute sql statement
          $stmt = oci_parse($conn, $sql);
          oci_execute($stmt);
        ?>

        <div class="container">
            <div class="bootstrap">
              <table class="table table-condensed table-hover table-responsive w-auto">
                  <thead>
                    <tr>
                      <th scope="col">Gebiet #</th>
                      <th scope="col">Staat</th>
                      <th scope="col">Name</th>
                      <th scope="col">Lifte/Bahnen</th>
                      <th scope="col">Piste, km</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                        // fetch rows of the executed sql query
                          while ($row = oci_fetch_assoc($stmt)) {
                              echo "<tr>";
                              echo "<td>" . $row['GEBIET_ID'] . "</td>";
                              echo "<td>" . $row['STAAT'] . "</td>";
                              echo "<td><a href='skigebiet_info.php?id=".$row['GEBIET_ID']."'>" . $row['BEZEICHNUNG'] . "</a></td>";
                              echo "<td>" . $row['LIFTEANZAHL'] . "</td>";
                              echo "<td>" . $row['PISTESTRECKE'] . "</td>";
                              echo "</tr>";
                          }
                    ?>
                  </tbody>
                </table>
            </div>
        </div>
        <div>Insgesamt <?php echo oci_num_rows($stmt); ?> Skigebiet gefunden!</div>
        <?php  oci_free_statement($stmt); ?>
      
      <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.js"></script>
      <!-- Include all compiled plugins (below), or include individual files as needed -->
      <script src="js/bootstrap.js"></script>
  </body>
</html>